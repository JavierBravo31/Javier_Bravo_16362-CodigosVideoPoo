class Persona:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
        
    def __str__(self):
        return f"Persona(nombre={self.nombre}, edad ={self.edad})"
    
    def __repr__(self):
        return f'Persona("{self.nombre}", {self.edad})'
    
    def __add__(self,otro):
        nuevo_valor= self.edad + otro.edad
        return Persona(self.nombre+otro.nombre,nuevo_valor)
    
javier = Persona ("Javier",19)
print(javier)

lista = (1,2,3)
print(lista)

repre = repr(javier)
resultado = eval(repre)
print(resultado.edad)
print(resultado.nombre)

anahi = Persona("Anahi",20)
angel = Persona("Angel",20)
nueva_persona = javier + angel +anahi
print(nueva_persona.nombre)
print(nueva_persona.edad)

