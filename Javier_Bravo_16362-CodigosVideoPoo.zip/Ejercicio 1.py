class Estudiante:
    def __init__(self,nombre,edad,semestre):
        self.nombre = nombre
        self.edad = edad
        self.semestre = semestre


javier = Estudiante("Javier", 19 ,2)


print(javier.semestre)