def recorrer(elemento):
    for item in elemento:
        print(f"El elemento actual es: {item}")
        
lista1 = [1,2,3,4,5]
lista2 = ["bro", "como", "estas"]

recorrer(lista1)
recorrer(lista2)