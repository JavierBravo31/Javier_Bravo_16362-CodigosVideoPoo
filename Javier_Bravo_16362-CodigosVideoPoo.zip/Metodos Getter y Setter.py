class Persona: 
    def __init__(self, nombre,edad):
        self._nombre = nombre
        self._edad = edad

    def get_nombre(self):
        return self._nombre
    
    def set_nombre(self, new_nombre):
        self._nombre = new_nombre

joven = Persona("Javier",19) 


nombre = joven.get_nombre
print(joven._nombre) 


joven.set_nombre("Javielito")
print(joven._nombre)


name =input("Ingrese el nombre de su personaje")
joven.set_nombre(name)
print(joven._nombre)

