from abc import ABC, abstractclassmethod

class Persona(ABC):
    @abstractclassmethod
    def __init__(self, nombre, edad, género, actividad):
        self.nombre = nombre
        self.edad = edad
        self.género = género
        self.actividad = actividad 
        
    @abstractclassmethod
    def hacer_actividad(self):
        pass
    
    def presentarse(self):
        print(f"Hola mi nombre es {self.nombre} y tengo {self.edad} años de edad, soy de género {self.género}")

class Estudiante(Persona):
    def __init__ (self, nombre, edad, género, actividad):
        super().__init__(nombre, edad, género, actividad)
        
    def hacer_actividad(self):
        print(f"Estoy estudiando: {self.actividad}")
        

class Trabajador(Persona):
    def __init__ (self, nombre, edad, género, actividad):
        super().__init__(nombre, edad, género, actividad)
        
    def hacer_actividad(self):
        print(f"Estoy trabajaando de {self.actividad}")
        
javier = Estudiante("Javier", 19, "masculino", "Ing. Tecnologías de la información")
bryan = Trabajador("Bryan", 27, "masculino", "Asesor de ventas")

javier.presentarse()
javier.hacer_actividad()
bryan.presentarse()
bryan.hacer_actividad()
