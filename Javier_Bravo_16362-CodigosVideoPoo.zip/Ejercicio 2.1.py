class Animal: 
    def comer(self):
        print("come")
    
    
class Mamifero(Animal):
    def criar(self):
        print("cria")
        
class Cetaceo(Animal): 
    def nadar (self):
        print("nada")
        
class Ballena(Mamifero, Cetaceo):
    pass

ballena2 = Ballena()

ballena2.comer()
ballena2.criar()
ballena2.nadar()

