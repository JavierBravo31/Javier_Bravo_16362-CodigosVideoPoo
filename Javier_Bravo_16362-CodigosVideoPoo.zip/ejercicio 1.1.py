class Estudiante:
    def __init__(self,nombre,edad,semestre):
        self.nombre = nombre
        self.edad = edad
        self.semestre = semestre

nombre = input("Digame su nombre")
edad = input("Ahora su edad:")
semestre = input("Por ultimo, su semestre")

estudiante = Estudiante(nombre,edad, semestre)

print(f"""
    DATOS DEL ESTUDIANTE: \n\n
    Nombre: {estudiante.nombre} \n
    Edad: {estudiante.edad} \n 
    Semestre: {estudiante.semestre} \n 

    """)

while True:
    estudiar = input()
    if (estudiar.lower == "estudiar"):
        estudiante.estudiar
