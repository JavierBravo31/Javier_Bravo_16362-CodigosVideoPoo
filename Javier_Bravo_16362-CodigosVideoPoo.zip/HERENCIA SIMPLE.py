class Persona:
    def __init__(self, nombre, edad, nacionalidad):
        self.nombre = nombre
        self.edad = edad
        self.nacionalidad = nacionalidad
    
    def hablar(self):
        print(f"Buenas noches soy {self.nombre} y me gusta conversar mucho")

class Empleado(Persona):
    def __init__(self, nombre, edad, nacionalidad, trabajo, salario):
        super().__init__(nombre, edad, nacionalidad)
        self.trabajo = trabajo
        self.salario = salario

Javier = Empleado("Javier", "19", "Ecuatoriano", "Mesero", "450")
Javier.hablar()

class Estudiante(Persona):
    def __init__(self, nombre, edad, nacionalidad, universidad, carrera):
        super().__init__(nombre, edad, nacionalidad)
        self.universidad = universidad
        self.carrera = carrera

Javier = Estudiante("Javier", "19", "Ecuatoriano", "ESPE", "ING. Tecnologias de la información")
print("El estudiante", Javier.nombre, "tiene", Javier.edad, "años, estudia en la", Javier.universidad, "en la carrera", Javier.carrera)

Javier.hablar()